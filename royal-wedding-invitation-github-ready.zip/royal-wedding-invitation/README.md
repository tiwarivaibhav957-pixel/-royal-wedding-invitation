# Royal Wedding Invitation

A minimal, mobile-first royal Indian digital invitation card. It has no database, no RSVP, no admin panel, and no contact-number fields.

## Run locally
1. Install Node.js (18+).
2. Extract this folder and open a terminal inside it.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local URL shown by Vite.

## Personalize
Edit `src/wedding.ts` only:
- bride / groom
- date and time
- venue and address
- invitation message
- background photograph URL

The current names and wedding details are placeholders. Replace them with the real details before publishing.

## Build
Run `npm run build`. Upload the generated `dist` folder to Netlify, or deploy the repository with Vercel. For GitHub Pages, configure the Vite `base` path to your repository name before building.

## Music
The card currently includes a visible music control placeholder but no audio file is bundled. To add music, use a royalty-free or personally licensed MP3 and implement playback after a guest taps the control. It does not autoplay.
