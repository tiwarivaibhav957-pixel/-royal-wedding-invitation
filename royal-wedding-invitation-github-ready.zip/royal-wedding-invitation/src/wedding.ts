// Wedding information transcribed from the physical invitation.
// Edit this file to change any wedding details. The website design is unchanged.
export const wedding = {
  bride: 'Anita Kumari',
  groom: 'Saurabh Kumar',
  date: '9 December 2026',
  time: 'Baraat arrival and wedding ceremony at night',
  venue: 'Sushma Resort',
  address: 'Bihta–Sarmera Road, Naubatpur (Patna), Bihar, India',
  familyMessage: 'With the blessings of our families, we warmly invite you to join us and bless the couple as they begin their new journey together.',
  events: [
    { date: '5 December 2026 (Saturday)', title: 'Tilak (Dhanwati) and Matkor' },
    { date: '7 December 2026 (Monday)', title: 'Mehendi and Haldi Kalash' },
    { date: '8 December 2026 (Tuesday)', title: 'Devpujan and Dhritdhari' },
    { date: '9 December 2026 (Wednesday)', title: 'Baraat arrival and wedding at night' }
  ],
  // Existing royal maroon-and-gold website background is intentionally retained.
  background: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=2000&q=90'
};
