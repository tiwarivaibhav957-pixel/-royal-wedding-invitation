import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Music2, Pause, Heart, Sparkles } from 'lucide-react';
import { wedding } from './wedding';

export default function App() {
  const [opened, setOpened] = useState(false);
  const [musicOn, setMusicOn] = useState(false);

  return (
    <main className="page" style={{ backgroundImage: `linear-gradient(rgba(42,10,17,.72), rgba(42,10,17,.78)), url(${wedding.background})` }}>
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <div className="outer-frame">
        <div className="inner-frame">
          <div className="corner corner-tl">❧</div><div className="corner corner-tr">❧</div>
          <div className="corner corner-bl">❧</div><div className="corner corner-br">❧</div>
          <div className="top-flower">✿</div>

          <AnimatePresence mode="wait">
            {!opened ? (
              <motion.section className="card-content" key="front" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: .96, rotateX: 8 }} transition={{ duration: .8 }}>
                <p className="invocation">॥ श्री गणेशाय नमः ॥</p>
                <div className="gold-rule"><span>✦</span></div>
                <p className="together">Together with our families</p>
                <p className="invite-line">request the honour of your presence<br/>at the wedding celebration of</p>
                <h1 className="names">{wedding.bride}<span className="ampersand">&</span>{wedding.groom}</h1>
                <div className="gold-rule lower"><span>❧</span></div>
                <p className="date">{wedding.date}</p>
                <button className="open-button" onClick={() => setOpened(true)}>Open Invitation <span>✧</span></button>
                <p className="blessing">With love, joy & blessings</p>
              </motion.section>
            ) : (
              <motion.section className="card-content details" key="inside" initial={{ opacity: 0, rotateY: -12, scale: .96 }} animate={{ opacity: 1, rotateY: 0, scale: 1 }} transition={{ duration: 1, ease: 'easeOut' }}>
                <p className="invocation">॥ श्री गणेशाय नमः ॥</p>
                <div className="gold-rule"><span>✦</span></div>
                <p className="together">With the blessings of our loved ones</p>
                <h1 className="names">{wedding.bride}<span className="ampersand">&</span>{wedding.groom}</h1>
                <p className="invite-line">{wedding.familyMessage}</p>
                <div className="detail-block">
                  <Sparkles size={17} strokeWidth={1.3}/>
                  <p className="date">{wedding.date}</p>
                  {wedding.time && <p className="detail-text">{wedding.time}</p>}
                </div>
                <div className="detail-block venue">
                  <p className="venue-label">THE CELEBRATION</p>
                  <p className="venue-name">{wedding.venue}</p>
                  <p className="detail-text">{wedding.address}</p>
                </div>
                <div className="schedule">
                  <p className="venue-label">WEDDING CELEBRATIONS</p>
                  {wedding.events.map((event) => (
                    <div className="schedule-row" key={event.date}>
                      <span className="schedule-date">{event.date}</span>
                      <span className="schedule-title">{event.title}</span>
                    </div>
                  ))}
                </div>
                <div className="gold-rule lower"><span>❧</span></div>
                <p className="blessing">Your presence will make our day even more special.</p>
                <p className="with-love">With Love & Blessings</p>
              </motion.section>
            )}
          </AnimatePresence>
          <div className="bottom-flower">✿</div>
        </div>
      </div>
      <button className="music-button" onClick={() => setMusicOn(!musicOn)} aria-label={musicOn ? 'Turn music off' : 'Turn music on'}>
        {musicOn ? <Pause size={16}/> : <Music2 size={16}/>} <span>{musicOn ? 'Music on' : 'Music off'}</span>
      </button>
      <p className="page-note">A celebration of love and togetherness</p>
    </main>
  );
}
