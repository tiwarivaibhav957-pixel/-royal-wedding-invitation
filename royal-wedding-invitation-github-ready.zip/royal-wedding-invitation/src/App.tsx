import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Heart, Sparkles, RotateCcw } from 'lucide-react';
import { wedding } from './wedding';

export default function App() {
  const [opened, setOpened] = useState(false);
  const [knotOpening, setKnotOpening] = useState(false);

  const startOpening = () => {
    if (knotOpening || opened) return;
    setKnotOpening(true);
    window.setTimeout(() => setOpened(true), 1750);
  };

  return (
    <main className="page">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <div className="petals" aria-hidden="true">
        {Array.from({ length: 12 }, (_, i) => (
          <span key={i} style={{ left: `${(i * 29) % 100}%`, animationDelay: `${(i % 6) * 0.8}s`, animationDuration: `${9 + (i % 4) * 2}s` }}>✿</span>
        ))}
      </div>

      <div className="page-heading">A CELEBRATION OF LOVE</div>

      <div className="card-stage">
        <div className="card-shadow" />
        <div className="invitation-card">
          <motion.div className="inside-card" initial={{ opacity: 0, y: 310, scale: 0.62, transformOrigin: "center bottom" }} animate={opened ? { opacity: 1, y: 0, scale: 1, transition: { duration: 3.15, delay: 0.35, ease: [0.22, 0.72, 0.2, 1] } } : { opacity: 0, y: 310, scale: 0.62 }}>
            <div className="inner-border">
              <div className="ornament">✧ ❧ ✧</div>
              <p className="ganesh">॥ श्री गणेशाय नमः ॥</p>
              <div className="gold-rule"><span>✿</span></div>
              <p className="eyebrow">WITH THE BLESSINGS OF OUR FAMILIES</p>
              <h1 className="names">{wedding.bride}<span>&</span>{wedding.groom}</h1>
              <p className="welcome">{wedding.message}</p>
              <div className="date-area">
                <Sparkles size={17} />
                <strong>{wedding.date}</strong>
                <span>{wedding.time}</span>
              </div>
              <section className="events">
                <p className="section-kicker">WEDDING CELEBRATIONS</p>
                {wedding.events.map((event) => (
                  <div className="event" key={event.date}>
                    <div className="event-date"><b>{event.date}</b><small>{event.day}</small></div>
                    <span>{event.title}</span>
                  </div>
                ))}
              </section>
              <section className="venue">
                <p className="section-kicker">THE WEDDING VENUE</p>
                <h2>{wedding.venue}</h2>
                <p>{wedding.address}</p>
              </section>
              <p className="closing">Your presence will be our greatest blessing.</p>
              <div className="ornament bottom-ornament">❧ ♥ ❧</div>
            </div>
          </motion.div>

          <AnimatePresence>
            {!opened && (
              <motion.div
                className="cover"
                initial={{ y: 0, opacity: 1 }}
                exit={{
                  y: "108%",
                  opacity: 0,
                  transition: { duration: 2.35, ease: [0.65, 0, 0.35, 1], opacity: { duration: 0.8, delay: 1.5 } },
                }}
              >
                <div className={`ribbon-wrap${knotOpening ? ' untie' : ''}`} aria-hidden="true">
                  <div className="ribbon-horizontal" />
                  <div className="ribbon-vertical" />
                  <div className="bow">
                    <span className="bow-loop bow-left" />
                    <span className="bow-loop bow-right" />
                    <span className="bow-knot" />
                    <span className="bow-tail tail-left" />
                    <span className="bow-tail tail-right" />
                  </div>
                </div>
                <div className="cover-border">
                  <div className="cover-top">॥ श्री गणेशाय नमः ॥</div>
                  <div className="cover-flower">✿</div>
                  <p className="cover-kicker">A SPECIAL INVITATION FOR YOU</p>
                  <div className="cover-names">{wedding.bride}<span>&</span>{wedding.groom}</div>
                  <button className="open-button" onClick={startOpening} disabled={knotOpening}>
                    {knotOpening ? 'UNTYING THE RIBBON…' : 'UNTIE THE RIBBON'} <span>✦</span>
                  </button>
                  <p className="tap-note">A LITTLE CELEBRATION, A LIFETIME OF LOVE</p>
                </div>
                <div className="cover-spine" />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <AnimatePresence>
        {opened && (
          <motion.button className="replay" onClick={() => { setOpened(false); setKnotOpening(false); }}
            initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }} transition={{ delay: 0.55 }}>
            <RotateCcw size={14} /> Replay invitation opening
          </motion.button>
        )}
      </AnimatePresence>

      <footer>MADE WITH LOVE · {wedding.bride.toUpperCase()} & {wedding.groom.toUpperCase()}</footer>
    </main>
  );
}
