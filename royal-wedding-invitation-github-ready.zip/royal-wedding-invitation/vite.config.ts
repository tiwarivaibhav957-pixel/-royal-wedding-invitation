import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  // Relative asset paths allow this project to work under a GitHub Pages repo URL.
  base: './',
  plugins: [react()]
});
